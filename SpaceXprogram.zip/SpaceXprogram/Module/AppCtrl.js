﻿var app;
(function () {
    'use strict'; //Defines that JavaScript code should be executed in "strict mode"  
    app = angular.module('XspaceApp', ['angular.filter']);
})();